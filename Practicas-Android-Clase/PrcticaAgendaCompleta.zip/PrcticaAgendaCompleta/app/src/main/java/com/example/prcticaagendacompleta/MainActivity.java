package com.example.prcticaagendacompleta;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Map;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> datosAgenda;
    private ArrayAdapter<String> adaptadorDatos;
    private ListView lView1;
    private EditText texto1, texto2;
    private SharedPreferences misPreferencias;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto1 = findViewById(R.id.textoNombre);
        texto2 = findViewById(R.id.textoTelefono);
        lView1 = findViewById(R.id.listaSQL);

        datosAgenda = new ArrayList<>();
        adaptadorDatos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, datosAgenda);
        lView1.setAdapter(adaptadorDatos);

        misPreferencias = getSharedPreferences("datosMoviles", Context.MODE_PRIVATE);
        leerPreferencias();

        lView1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                eliminarRegistro(position);
                return true;
            }
        });
    }

    public void agregarRegistro(View view) {
        String nombre = texto1.getText().toString();
        String movil = texto2.getText().toString();

        // PARA NO INTRODUCIR REGISTROS VACIOS.
        if (nombre.isEmpty() || movil.isEmpty()) {
            Toast.makeText(this, "Complete ambos campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // INGRESAR REGISTROS EN EL SQL.
        MySQLiteOpenHelper manejador = new MySQLiteOpenHelper(this, "contactos", null, 1);
        SQLiteDatabase bd = manejador.getWritableDatabase();
        ContentValues registros = new ContentValues();
        registros.put("nombre", nombre);
        registros.put("movil", movil);
        bd.insert("contactos", null, registros);
        bd.close();

        // AGREGAR LAS PREFERENCIAS.
        SharedPreferences.Editor editor = misPreferencias.edit();
        editor.putString(nombre, movil);
        editor.apply();

        // AÑADIR EL CONTENIDO DE LOS EDIT TEXTS EN EL LIST VIEW.
        datosAgenda.add(nombre + " : " + movil);
        adaptadorDatos.notifyDataSetChanged();
        texto1.setText("");
        texto2.setText("");

        Toast.makeText(this, "Contacto agregado", Toast.LENGTH_SHORT).show();
    }

    private void leerPreferencias() {
        Map<String, ?> claves = misPreferencias.getAll();
        for (Map.Entry<String, ?> ele : claves.entrySet()) {
            datosAgenda.add(ele.getKey() + " : " + ele.getValue().toString());
        }
    }

    private void eliminarRegistro(int posicion) {
        String registro = datosAgenda.get(posicion);
        StringTokenizer tok1 = new StringTokenizer(registro, ":");
        String nombre = tok1.nextToken().trim();

        AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
        dialogo.setTitle("Eliminar Contacto")
                .setMessage("¿Desea eliminar este contacto?")
                .setCancelable(false)
                .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences.Editor editor = misPreferencias.edit();
                        editor.remove(nombre);
                        editor.apply();

                        datosAgenda.remove(posicion);
                        adaptadorDatos.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Contacto eliminado", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
}}