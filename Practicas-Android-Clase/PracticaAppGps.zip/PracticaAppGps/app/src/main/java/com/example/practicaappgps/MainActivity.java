package com.example.practicaappgps;

import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;

public class MainActivity extends AppCompatActivity {

    private final int CODIGO_PERMISO_UBICACION = 1;
    private TextView textoGps;
    private LocationManager localizacion;
    private LocationListener avisoGps;

    public void solicitarPermiso(String permiso, int codPermiso) {
        if (ContextCompat.checkSelfPermission(this, permiso) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { permiso }, codPermiso);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CODIGO_PERMISO_UBICACION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permiso concedido, comenzar a recibir actualizaciones
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    localizacion.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, avisoGps);
                }
            } else {
                textoGps.setText("Permiso de ubicación denegado.");
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("gpsapp", "INICIO ONCREATE");
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Ajuste de márgenes para dispositivos con "notch" o barras de estado/teclado
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textoGps = findViewById(R.id.textoCoordenadas);

        // Solicitar permiso de ubicación al inicio
        solicitarPermiso(Manifest.permission.ACCESS_FINE_LOCATION, CODIGO_PERMISO_UBICACION);

        // Obtener el servicio de LocationManager
        localizacion = (LocationManager) getSystemService(LOCATION_SERVICE);
        Log.d("APP", "ANTES DE LOCATIONLISTENE");

        // Crear el LocationListener para manejar cambios de ubicación
        avisoGps = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                Log.d("APP", "UBICACION CAMBIADA");
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                textoGps.setText("Latitud: " + latitude + "\n" + "Longitud: " + longitude);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                Log.d("APP", "UBICACION CAMBIADA");

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                Log.d("APP", "UBICACION CAMBIADA");

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                Log.d("APP", "UBICACION CAMBIADA");

            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Comprobar si se tiene permiso para acceder a la ubicación
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            localizacion.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, avisoGps);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Detener las actualizaciones cuando la actividad esté en pausa
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            localizacion.removeUpdates(avisoGps);
        }
    }
}