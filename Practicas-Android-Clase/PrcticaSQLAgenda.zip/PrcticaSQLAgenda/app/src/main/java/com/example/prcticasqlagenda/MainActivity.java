package com.example.prcticasqlagenda;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Map;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> datosAgenda;
    private ArrayAdapter<String> adaptadorDatos;
    private ListView lView1;
    private EditText texto1, texto2, texto3;
    private SharedPreferences misPreferencias;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto1 = findViewById(R.id.idProducto);
        texto2 = findViewById(R.id.textoDescripcion);
        texto3 = findViewById(R.id.textoPrecio);
        lView1 = findViewById(R.id.listaSQL);

        datosAgenda = new ArrayList<>();
        adaptadorDatos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, datosAgenda);
        lView1.setAdapter(adaptadorDatos);

        misPreferencias = getSharedPreferences("datosMoviles", Context.MODE_PRIVATE);
        leerPreferencias();

        lView1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                eliminarRegistro(position);
                return true;
            }
        });
    }

    public void agregarRegistro(View view) {
        String clave = texto1.getText().toString();
        String descripcion = texto2.getText().toString();
        String precio = texto3.getText().toString();

        // PARA NO INTRODUCIR REGISTROS VACIOS.
        if (clave.isEmpty() || descripcion.isEmpty() || precio.isEmpty()) {
            Toast.makeText(this, "Complete la información en los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // INGRESAR REGISTROS EN EL SQL.
        MySQLiteOpenHelper manejador = new MySQLiteOpenHelper(this, "productos", null, 1);
        SQLiteDatabase bd = manejador.getWritableDatabase();
        ContentValues registros = new ContentValues();
        registros.put("clave", clave);
        registros.put("descripcion", descripcion);
        registros.put("precio", precio);
        bd.insert("contactos", null, registros);
        bd.close();

        // AGREGAR LAS PREFERENCIAS.
        SharedPreferences.Editor editor = misPreferencias.edit();
        editor.putString(clave + "_descripcion", descripcion);
        editor.putString(clave + "_precio", precio);
        editor.apply();

        // AÑADIR EL CONTENIDO DE LOS EDIT TEXTS EN EL LIST VIEW.
        datosAgenda.add("Clave: " + clave + " Descripción: " + descripcion + " Precio: " + precio + "€");
        adaptadorDatos.notifyDataSetChanged();
        Toast.makeText(this, "Contacto agregado", Toast.LENGTH_SHORT).show();
    }

    private void leerPreferencias() {
        Map<String, ?> claves = misPreferencias.getAll();
        for (Map.Entry<String, ?> ele : claves.entrySet()) {
            String key = ele.getKey();
            if (key.endsWith("_descripcion")) { // Solo leer descripciones
                String clave = key.replace("_descripcion", "");
                String descripcion = ele.getValue().toString();
                String precio = misPreferencias.getString(clave + "_precio", "0"); // Obtener precio correspondiente
                datosAgenda.add("Clave: " + clave + " Descripción: " + descripcion + " Precio: " + precio + "€");
            }
        }
        adaptadorDatos.notifyDataSetChanged();
    }

    private void eliminarRegistro(int posicion) {
        String registro = datosAgenda.get(posicion);
        StringTokenizer tok1 = new StringTokenizer(registro, ":");
        String nombre = tok1.nextToken().trim();

        AlertDialog.Builder dialogo = new AlertDialog.Builder(MainActivity.this);
        dialogo.setTitle("Eliminar Producto")
                .setMessage("¿Desea eliminar este producto?")
                .setCancelable(false)
                .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        SharedPreferences.Editor editor = misPreferencias.edit();
                        editor.remove(nombre);
                        editor.apply();
                        datosAgenda.remove(posicion);
                        adaptadorDatos.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "producto eliminado", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }}