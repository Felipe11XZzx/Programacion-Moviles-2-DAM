package com.example.prcticasharedpreferences;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText texto1, texto2;
    private SharedPreferences prefe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        texto1 = (EditText) findViewById(R.id.nombrePersona);
        texto2 = (EditText) findViewById(R.id.datosGuardar);
        prefe=getSharedPreferences("informacion", Context.MODE_PRIVATE);
    }
    public void guardarDatos(View v){
        String nombre = texto1.getText().toString();
        String datos = texto2.getText().toString();
        SharedPreferences.Editor editor = prefe.edit();
        editor.putString(nombre, datos);
        editor.commit();
        texto1.setText("");
        texto2.setText("");
    }

    public void mostrarDatos(View v){
        String nombre = texto1.getText().toString();
        String datos = prefe.getString(nombre, null);
        texto2.setText(datos);
    }
}