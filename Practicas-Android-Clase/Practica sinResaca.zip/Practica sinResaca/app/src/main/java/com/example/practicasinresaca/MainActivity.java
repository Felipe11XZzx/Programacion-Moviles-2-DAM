package com.example.practicasinresaca;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private String  peticion_datosApi;
    private ArrayAdapter<String> adaptadorDatos;
    private ListView lView1;
    private OkHttpClient client;
    private ArrayList<String> datosBebidas;
    private ArrayList<String> IDdrink;
    private EditText textoError;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Inicializar textoError para evitar NullPointerException
        textoError = findViewById(R.id.textoError); // Asegúrate de tener este EditText en tu layout.

        client = new OkHttpClient();
        lView1 = findViewById(R.id.listaCocteles);
        datosBebidas = new ArrayList<>();
        IDdrink = new ArrayList<>();
        adaptadorDatos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, datosBebidas);
        lView1.setAdapter(adaptadorDatos);
        realizarBusqueda();

        lView1.setOnItemClickListener((adapterView, view, i, l) -> {
            String drinkID = IDdrink.get(i);
            Intent intento = new Intent(getApplicationContext(), MainActivity2.class);
            intento.putExtra("id", drinkID);
            startActivity(intento);
        });
    }

    private void realizarBusqueda() {
        peticion_datosApi = "https://www.thecocktaildb.com/api/json/v1/1/filter.php?a=Non_Alcoholic";

        Request peticion = new Request.Builder().url(peticion_datosApi).build();

        client.newCall(peticion).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                runOnUiThread(() -> textoError.setText("Error en la petición HTTPS: " + e.getMessage()));
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()) {
                    String respuesta = response.body().string();

                    // Log de la respuesta para depuración
                    runOnUiThread(() -> textoError.setText("Respuesta API recibida correctamente."));

                    try {
                        JSONObject objetoJSON = new JSONObject(respuesta);
                        JSONArray drinksList = objetoJSON.getJSONArray("drinks");

                        for (int i = 0; i < drinksList.length(); i++) {
                            JSONObject drink = drinksList.getJSONObject(i);
                            String drinkName = drink.getString("strDrink");
                            String drinkId = drink.getString("idDrink");
                            datosBebidas.add(drinkName);
                            IDdrink.add(drinkId);
                        }

                        runOnUiThread(() -> adaptadorDatos.notifyDataSetChanged());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        runOnUiThread(() -> textoError.setText("Error al procesar los datos JSON: " + e.getMessage()));
                    }
                } else {
                    runOnUiThread(() -> textoError.setText("Error en la respuesta HTTP: Código " + response.code()));
                }
            }
        });
    }
}