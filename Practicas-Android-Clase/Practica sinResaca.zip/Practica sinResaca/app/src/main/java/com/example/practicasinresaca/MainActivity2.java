package com.example.practicasinresaca;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity2 extends AppCompatActivity {

    private String peticion_datosApi;
    private ArrayAdapter<String> adaptadorDatos;
    private ListView lView2;
    private OkHttpClient client;
    private ArrayList<String> datosBebidas;
    private TextView tituloCoctel;
    private ImageView imagenCoctel;
    private TextView ingredientesCoctel;
    private String idDrink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2); // Cambiado al layout correcto

        // Inicializar vistas
        lView2 = findViewById(R.id.listaIngredientes);
        tituloCoctel = findViewById(R.id.nombreCoctel);
        imagenCoctel = findViewById(R.id.ImagenCoctel);
        ingredientesCoctel = findViewById(R.id.ingredientesCoctel);
        client = new OkHttpClient();
        datosBebidas = new ArrayList<>();
        adaptadorDatos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, datosBebidas);
        lView2.setAdapter(adaptadorDatos);

        // Obtener el ID del cóctel desde el Intent
        Intent intent = getIntent();
        idDrink = intent.getStringExtra("id");

        if (idDrink != null && !idDrink.isEmpty()) {
            realizarBusqueda();
        } else {
            Log.e("MainActivity2", "ID de cóctel no recibido o vacío.");
        }
    }

    private void realizarBusqueda() {
        peticion_datosApi = "https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=" + idDrink;

        Request peticion = new Request.Builder().url(peticion_datosApi).build();

        client.newCall(peticion).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("MainActivity2", "Error en la petición HTTPS: " + e.getMessage());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String respuesta = response.body().string();

                    try {
                        JSONObject objetoJSON = new JSONObject(respuesta);
                        JSONArray drinksList = objetoJSON.getJSONArray("drinks");
                        JSONObject drink = drinksList.getJSONObject(0);

                        String drinkName = drink.getString("strDrink");
                        String manualDrink = drink.getString("strInstructions");
                        String pathImage = drink.getString("strDrinkThumb");

                        // Limpiar la lista de ingredientes
                        datosBebidas.clear();

                        for (int i = 1; i <= 15; i++) {
                            String idIngredient = "strIngredient" + i;
                            String quantyMeasure = "strMeasure" + i;

                            String descriptionIngredient = drink.optString(idIngredient, null);
                            String quantity = drink.optString(quantyMeasure, null);

                            if (descriptionIngredient != null && !descriptionIngredient.isEmpty()) {
                                datosBebidas.add("Ingrediente " + i + ": " + descriptionIngredient +
                                        "  Cantidad: " + (quantity != null ? quantity : "Desconocida"));
                            }
                        }

                        // Actualizar UI en el hilo principal
                        runOnUiThread(() -> {
                            Glide.with(MainActivity2.this).load(pathImage).into(imagenCoctel);
                            tituloCoctel.setText(drinkName);
                            ingredientesCoctel.setText(manualDrink);
                            adaptadorDatos.notifyDataSetChanged();
                        });

                    } catch (JSONException e) {
                        Log.e("MainActivity2", "Error al procesar los datos JSON: " + e.getMessage());
                    }
                } else {
                    Log.e("MainActivity2", "Respuesta no exitosa: Código " + response.code());
                }
            }
        });
    }
}
