package com.example.practicacamaragps;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.Manifest;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.util.function.Consumer;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int GPS_PERMISSION_CODE = 1;
    private ImageView imagen1;
    private EditText et1;
    private LocationManager locationManager;
    private LocationListener avisoGps;
    private TextView textoGps;
    private double latitud;
    private double longitud;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagen1 = findViewById(R.id.imagenApp);
        et1 = findViewById(R.id.textoFoto);
        textoGps = findViewById(R.id.textoGps);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        // Solicitar permisos necesarios
        solicitarPermiso(Manifest.permission.CAMERA, REQUEST_IMAGE_CAPTURE);
        solicitarPermiso(Manifest.permission.ACCESS_FINE_LOCATION, GPS_PERMISSION_CODE);

        // Configurar el LocationListener para actualizaciones de ubicación
        avisoGps = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                if (location != null) {
                    longitud = location.getLongitude();
                    latitud = location.getLatitude();
                    Log.d("MYAPP", "Latitud: " + latitud + ", Longitud: " + longitud);
                    textoGps.setText("Latitud Actual GPS: \n" + latitud + "\n" + "\nLongitud Actual GPS: \n" + longitud);
                } else {
                    Log.d("MYAPP", "0Ubicación no disponible.");
                }
            }
            public void onStatusChanged(String provider, int status, Bundle extras) {}
            public void onProviderEnabled(String provider) {}
            public void onProviderDisabled(String provider) {}
        };

        // Verificar permiso y comenzar a actualizar ubicación si es necesario
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, avisoGps);
        }
    }

    // Función para solicitar permisos
    public void solicitarPermiso(String permiso, int codPermiso) {
        if (ContextCompat.checkSelfPermission(this, permiso) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { permiso }, codPermiso);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == GPS_PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 1, avisoGps);
            }
        } else if (requestCode == GPS_PERMISSION_CODE) {
            textoGps.setText("Permiso de ubicación denegado.");
        }
    }

    public void tomarFoto(View v) {
        Intent intento1 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File foto = new File(getFilesDir(), et1.getText().toString());
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", foto);
        intento1.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(intento1, REQUEST_IMAGE_CAPTURE);
    }

    public void recuperarFoto(View v) {
        Bitmap bitmap1 = BitmapFactory.decodeFile(getFilesDir() + "/" + et1.getText().toString());
        imagen1.setImageBitmap(bitmap1);
    }

    public void ver(View v) {
        Intent intento1 = new Intent(this, MainListaFotos.class);
        startActivity(intento1);
    }

    public void verUbicacion(View view) {
        String uri = String.format("geo:%f,%f?q=%f,%f(Ubicación de %s)", latitud, longitud, latitud, longitud, et1.getText().toString());
        Uri gmmIntentUri = Uri.parse(uri);
        Intent intent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        startActivity(intent);
    }

    private String convertToExifFormat(double coordinate) {
        if(coordinate < 0) coordinate = -coordinate;
        int degrees = (int) coordinate;
        double minutes = (coordinate - degrees) * 60;
        int minutesInt = (int) minutes;
        double seconds = (minutes - minutesInt) * 60 * 1000;
        int secondsInt = (int) seconds;
        return String.format("%d/1,%d/1,%d/1000", degrees, minutesInt, secondsInt);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            File foto = new File(getFilesDir(), et1.getText().toString());
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.getCurrentLocation(LocationManager.GPS_PROVIDER, null, getMainExecutor(),
                        new Consumer<Location>() {
                            @Override
                            public void accept(Location location) {
                                if (location != null) {
                                    longitud = location.getLongitude();
                                    latitud = location.getLatitude();
                                    try {
                                        ExifInterface exif = new ExifInterface(foto.getAbsolutePath());
                                        exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE, convertToExifFormat(latitud));
                                        exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE, convertToExifFormat(longitud));
                                        exif.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, latitud >= 0 ? "N" : "S");
                                        exif.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, longitud >= 0 ? "E" : "W");
                                        exif.saveAttributes();
                                        Log.d("MYAPP", "Ubicación guardado con Latitud: " + latitud + ", Longitud: " + longitud);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        });
            }
        }
    }
}
